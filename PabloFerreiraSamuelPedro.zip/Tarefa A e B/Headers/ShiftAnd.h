#ifndef SHIFTAND_H
#define SHIFTAND_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int * FazMascara(char * P,int M);
void ShiftAnd(char * P, char * T,int m,int n);
#endif
