#ifndef LEITURA_ARQ_H
#define LEITURA_ARQ_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char* LeituraArq(char * Entrada); //Leitura de texto de entrada

#endif
